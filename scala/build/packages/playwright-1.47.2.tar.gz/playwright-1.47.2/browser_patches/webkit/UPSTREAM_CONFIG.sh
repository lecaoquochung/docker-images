REMOTE_URL="https://github.com/WebKit/WebKit.git"
BASE_BRANCH="main"
BASE_REVISION="a47deb713746fa2f228e8450a52ed0ecafc5309d"
