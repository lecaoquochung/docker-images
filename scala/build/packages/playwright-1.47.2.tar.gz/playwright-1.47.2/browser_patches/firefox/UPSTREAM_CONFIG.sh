REMOTE_URL="https://github.com/mozilla/gecko-dev"
BASE_BRANCH="release"
BASE_REVISION="4c9a3f8e2db68ae0a8fcf6bbf0574e3c0549ff49"
